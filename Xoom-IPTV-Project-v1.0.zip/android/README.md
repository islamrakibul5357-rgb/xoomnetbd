# Xoom IPTV Android / Android TV

Native Android project specification.

Recommended stack: Kotlin + AndroidX + Media3 ExoPlayer.

Default playlist:
http://172.16.254.200/tv.m3u8

Required features: M3U/HLS playback, automatic channel loading, search, favorites, fullscreen, Android TV D-pad navigation and reconnect/retry.

The private IP normally requires the device to be connected to the Xoom Net network.
