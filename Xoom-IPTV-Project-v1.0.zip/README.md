# Xoom IPTV
Xoom Net Communication IPTV player project.

Default playlist: http://172.16.254.200/tv.m3u8

Features planned/included in the Windows player: automatic playlist loading, M3U/HLS playback, search, favorites-ready structure, fullscreen, reconnect/retry, and Xoom IPTV branding.

Note: 172.16.254.200 is a private/internal IP and normally works only from the Xoom Net network.
